# Dollar Value

Com o layout novo do paypal, agora fica chato fazer as contas, hehe. O dollar value faz a conta de quanto custa um USD em BRL.

## Screenshot
![image](https://d1zjcuqflbd5k.cloudfront.net/files/acc_153379/1lSLR?response-content-disposition=inline;%20filename=Screen%20Shot%20on%202015-08-19%20at%2014%3A59%3A19.png&Expires=1440007471&Signature=VZt0z0yr~lgb0MgZ2doRi7Rpt7eKW7qwGiFcLtGHAa4SFavMYv5mnbY-3k9iu~Q429ptwHIax3IEwVst7tsm412usgK~fbkaNa9payZvRe87L06FmIfW0x1P6oPiIbwTPrUb0yH~gYSLuwYa29DZgTng5fVS8rOxcm00QOVr3Os_&Key-Pair-Id=APKAJTEIOJM3LSMN33SA)


## Download
[Click Here](https://github.com/djalmaaraujo/dollar-value/releases/download/0.0.1/dollar-value.zip)

## Installation

* Unzip the content in a folder that you won't delete;
* Type ```chrome://extensions/``` in the browser;
* Click in ```Load unpacked extension...```;
* Select the folder
* Refresh your paypal home

## License

[MIT License](http://djalmaarajo.mit-license.org/) © Djalma Araújo

---------------------------
